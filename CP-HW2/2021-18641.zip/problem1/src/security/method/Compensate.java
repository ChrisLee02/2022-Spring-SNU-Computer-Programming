package security.method;

public class Compensate extends RequestMethod{
	//don't modify or use this class
	//We will replace this class for grading
}
