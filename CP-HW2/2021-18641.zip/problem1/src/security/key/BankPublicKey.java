package security.key;


public class BankPublicKey extends BankKey {
    public BankPublicKey(String value) {
        super(value);
    }
}
