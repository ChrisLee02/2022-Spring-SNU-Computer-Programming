package relay.player;

public interface Swimmable {
    void swim();
}
