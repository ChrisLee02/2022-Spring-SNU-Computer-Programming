//
// Created by triom on 2022-05-30.
//

#ifndef PROBLEM2_YOURIMAGE_H
#define PROBLEM2_YOURIMAGE_H

void yourImageGenerator(void);


#endif //PROBLEM2_YOURIMAGE_H
