//
// Created by triom on 2022-05-17.
//

#ifndef PROBLEM2_UTILS_H
#define PROBLEM2_UTILS_H
/*#define FAIL 1
#define SUCCESS 0*/

namespace Util{
    enum CHANNELS{
        R,G,B,A
    };
    enum RESULT {
        SUCCESS = 0, FAIL = 1
    };
}

#endif //PROBLEM2_UTILS_H
