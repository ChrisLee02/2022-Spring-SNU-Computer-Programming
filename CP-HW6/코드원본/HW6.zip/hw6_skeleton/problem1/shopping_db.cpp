#include "shopping_db.h"

ShoppingDB::ShoppingDB() {

}

void ShoppingDB::add_product(std::string name, int price) {
    // TODO: Problem 1.1

}

bool ShoppingDB::edit_product(std::string name, int price) {
    // TODO: Problem 1.1
    return true;
}

void ShoppingDB::add_user(std::string username, std::string password, bool premium) {
    // TODO: Problem 1.2

}
