#include "admin_ui.h"

AdminUI::AdminUI(ShoppingDB &db, std::ostream& os): UI(db, os) { }

void AdminUI::add_product(std::string name, int price) {
    // TODO: Problem 1.1

}

void AdminUI::edit_product(std::string name, int price) {
    // TODO: Problem 1.1

}

void AdminUI::list_products() {
    // TODO: Problem 1.1

}
