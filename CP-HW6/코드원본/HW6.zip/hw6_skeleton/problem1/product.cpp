#include "product.h"

Product::Product(std::string name, int price): name(name), price(price) { }
