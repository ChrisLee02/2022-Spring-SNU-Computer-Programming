//
// Created by triom on 2022-05-16.
//
#include <cmath>
#include "LayerManipulator.h"
int BoxBlur(Layer *layer, int kernelSize, int rep) {
    //TODO: Problem 2.3
    return 0;
}

int LevelChanger(Layer *layer, int channel, int low, int mid, int high) {
    //TODO: Problem 2.3
    return 0;
}

int ChannelScaling(Layer *layer, int channel, float scaleRatio) {
    //TODO: Problem 2.3
    return 0;
}

int ChannelMask(Layer* mask, Layer* target, int channel){
    //TODO: Problem 2.4
    return 0;
}

int ColorMatcher(Layer* targetlayer, Layer* sourcelayer){
    //TODO: Problem 2.4
    return 0;
}