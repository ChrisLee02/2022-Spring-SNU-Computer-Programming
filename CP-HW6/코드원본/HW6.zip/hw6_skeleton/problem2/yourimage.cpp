//
// Created by triom on 2022-05-30.
//

#include "yourimage.h"

void yourImageGenerator(void){
    //TODO: Problem 2.5

}