//
// Created by triom on 2022-05-30.
//
#define STB_IMAGE_IMPLEMENTATION

#include <cmath>
#include <iostream>
#include <string>
#include "stb_image.h"

int main(int argv, char** argc){
    if(argv != 3) return 1;
    std::string image1 = argc[1];
    std::string image2 = argc[2];
    int w1, h1, c1, w2, h2, c2;
    uint8_t* input_image1 = stbi_load(image1.data(), &w1, &h1, &c1, 0);
    uint8_t* input_image2 = stbi_load(image2.data(), &w2, &h2, &c2, 0);

    double diff = 0.0;
    if(input_image1 == nullptr || input_image2== nullptr){
        std::cout << "Wrong Filepath" << std::endl;
        return 0;
    }
    else if(w1 == w2 && h1 == h2 && c1 == c2){
        bool okay = true;
        int i;

        for( i = 0; i<w1*h1*c1; i++){
            diff = std::abs((float) input_image1[i] - (float) input_image2[i]);
            if(diff > 2){
                okay = false;
                break;
            }
        }
        if (okay)
            std::cout << "GOOD " << std::endl;
        else{
            std::cout << "BAD pixel value at x: " << (i%(w1*c1))/(c1) << " y: " << i/(w1*c1) <<" channel : "<< i%c1 << " diff " <<  diff << std::endl;
        }
    }
    else{
        std::cout << "Different Image Size" << std::endl;
    }

    stbi_image_free(input_image1);
    stbi_image_free(input_image2);
    return 0;
}