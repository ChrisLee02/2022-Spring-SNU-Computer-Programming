//
// Created by triom on 2022-05-17.
//

#ifndef PROBLEM2_UTILS_H
#define PROBLEM2_UTILS_H
namespace Util{
    enum CHANNELS{
        R,G,B,A
    };
}

#endif //PROBLEM2_UTILS_H
